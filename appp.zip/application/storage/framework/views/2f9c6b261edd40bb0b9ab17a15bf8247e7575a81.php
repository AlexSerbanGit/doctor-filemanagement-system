<?php if(Session::has('success')): ?>
<div class="container">
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\documents-website\application\resources\views/parts/success.blade.php ENDPATH**/ ?>