<?php if(Session::has('error')): ?>
<div class="container-fluid">
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\documents-website\application\resources\views/parts/error.blade.php ENDPATH**/ ?>