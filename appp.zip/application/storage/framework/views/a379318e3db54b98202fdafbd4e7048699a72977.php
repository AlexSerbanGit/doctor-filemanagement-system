<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="table-responsive">
        <div class="alert alert-primary">
            <h1>Your documents</h1>
        </div>
        <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <tr>
            <th scope="col"><?php echo e($key+1); ?></th>
            <th scope="col"><?php echo e($document->title); ?></th>
            <td>
            
            <a href="<?php echo e(url('/download_document/'.$document->id)); ?>">
                <button type="button" class="btn btn-success"><i class="fas fa-download"></i></button>
            </a>            
            </td>            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>

        
    
        <!-- Modal -->
        <div class="modal fade" id="viewDocument" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal view document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Document protocol:</label>
                    <input type="text" placeholder="protocol" name="protocol" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Document password:</label>
                    <input type="text" placeholder="password" name="password" required class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success">Search <i class="fas fa-search"></i></button>
            </div>
            </div>
        </div>
        </div>
        
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\documents-website\application\resources\views/doctor/home.blade.php ENDPATH**/ ?>