<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        
        <div class="alert alert-primary">
            <h1>
                Documents
            </h1>
        </div>

        <div class="table-responsive">
            <form action="<?php echo e(url('/zip_files')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col"></th>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Type</th>
                    <th scope="col">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><input type="checkbox" name="check[<?php echo e($document->id); ?>]"></th>
                    <th scope="row"><?php echo e($key+1); ?></th>
                    <td><?php echo e($document->title); ?></td>
                    <td><?php if($document->role_id == 2): ?> Patient <?php elseif($document->role_id == 3): ?> Convenant <?php elseif($document->role_id == 4): ?> Doctor <?php endif; ?></td>
                    <td>    
                        <a download="<?php echo e($document->id.'.'.$document->extension); ?>" href="<?php echo e(url('/gg/'.$document->id.'.'.$document->extension)); ?>"><button type="button" class="btn btn-success"><i class="fas fa-download"></i></button></a>  
                        <a href="<?php echo e(url('admin/delete_document/'.$document->id)); ?>"><button class="btn btn-danger"><i class="fas fa-trash"></i></button></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
            </table>
            <button class="btn btn-success" style="margin-bottom: 10px"><i class="fas fa-download"></i> Download as zip file</button>
            </form>
            <a href="<?php echo e(url('/admin/run_cron_job')); ?>">
                <button class="btn btn-warning" style="color: white"><i class="fas fa-redo"></i> Run Cron Job NOW</button>
            </a>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\documents-website\resources\views/admin/documents.blade.php ENDPATH**/ ?>