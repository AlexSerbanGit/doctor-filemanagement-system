<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="table-responsive">
        <form action="<?php echo e(url('/zip_files')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="alert alert-primary">
            <h1>Your documents</h1>
        </div>
        <table class="table">
        <thead>
            <tr>
            <th scope="col"></th>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scopt="col">Receipt date</th>
            <th>Downloaded</th>
            <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <tr>
            <th><input type="checkbox" name="check[<?php echo e($document->id); ?>]"></th>
            <th scope="col"><?php echo e($key+1); ?></th>
            <th scope="col"><?php echo e($document->title); ?></th>
            <td><?php echo e($document->created_at); ?></td>
            <td><?php if($document->downloaded == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
            <td>
            
            <a href="<?php echo e(url('/download_document/'.$document->id)); ?>">
                <button type="button" class="btn btn-success"><i class="fas fa-download"></i></button>
            </a>            
            </td>     
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
            <?php echo e($documents->render()); ?>

            <button class="btn btn-success" style="margin-bottom: 10px"><i class="fas fa-download"></i> Download as zip file</button>
        </form>
        
    
        <!-- Modal -->
        <div class="modal fade" id="viewDocument" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal view document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Document protocol:</label>
                    <input type="text" placeholder="protocol" name="protocol" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Document password:</label>
                    <input type="text" placeholder="password" name="password" required class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success">Search <i class="fas fa-search"></i></button>
            </div>
            </div>
        </div>
        </div>
        
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.convenants', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\documents-website\application\resources\views/convenant/home.blade.php ENDPATH**/ ?>