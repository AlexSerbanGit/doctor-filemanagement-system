<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="alert alert-primary">
    <h1>Patients</h1>
</div>
<div class="table-responsive">  
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Reports</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($key+1); ?></th>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td>0</td>
      <td>
        <button class="btn btn-warning" data-toggle="modal" data-target="#editUser<?php echo e($user->id); ?>"><i class="fas fa-edit"></i></button>
        <button class="btn btn-danger" data-toggle="modal" data-target="#deleteUser<?php echo e($user->id); ?>"><i class="fas fa-trash"></i></button>
      </td>
    </tr>

    <div class="modal fade" id="editUser<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit patient</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?php echo e(url('admin/edit_patient/'.$user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="name" required class="form-control">
            </div>
            
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add patient</button>
        </div>
        </form>
        </div>
    </div>
    </div>

    <!-- Modal delete -->
    <div class="modal fade" id="deleteUser<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete patient</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
            Are you sure you want to <tag-random class="text-danger">delete</tag-random> this patient?
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="<?php echo e(url('admin/delete_patient/'.$user->id)); ?>">
                <button type="button" class="btn btn-danger">Delete patient</button>
            </a>
            </div>
        </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($users->render()); ?>

</div>  
<button class="btn btn-primary" data-toggle="modal" data-target="#addPatient">Add patient</button>

<!-- Modal -->
<div class="modal fade" id="addPatient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add new patient</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form action="<?php echo e(url('admin/add_patient')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        <div class="form-group">
            <label>Name:</label>
            <input type="text" name="name" placeholder="name" required class="form-control">
        </div>
        <div class="form-group">
            <label>Email:</label>
            <input type="text" name="email" placeholder="email" required class="form-control">
        </div>
        <div class="form-group">
            <label>Password:</label>
            <input type="text" name="password" placeholder="password" required class="form-control">
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add patient</button>
    </div>
    </form>
    </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\documents-website\resources\views/admin/patients.blade.php ENDPATH**/ ?>